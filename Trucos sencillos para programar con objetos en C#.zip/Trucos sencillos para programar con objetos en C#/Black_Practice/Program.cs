using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Black_Practice
{
    public class Program
    {
        static void Main(string[]args){

// *Declaracion de variables


int num = 1;

var num2 = "2"; // var es lo mismo que string

int num3 = new(); //Metodo

//--------------------------------------------

var num4 = 4.1;

num4 = 3;

Console.WriteLine(" 1* Variables dinamicas: ");


dynamic num5;
num5 = "Hola Mundo";
Console.WriteLine(num5);

Console.WriteLine("");

//--------------------------------------------

// *OBJETOS (Las Clases Sirven Para crear objetos):
Console.WriteLine(" 2* Objeos: ");


//Objeto Cerveza
     var CervezaA = 
     
     new Bebida() {Nombre2 = "Cerveza Light"}; //Constructor 2 para la funcion Brand
       //Clase

//var Agua = new Bebida()/* obj */ {Nombre = "Brisa", Nombre1 = "Cristal"};

//Asignacion de objeto              Clase y numero de asignaciones

//var Cafe = new Bebida()/* obj {Nombre = "LaBastilla", Nombre1 = "Lukafe"};

     var Cerveza = new Bebida()/* obj */ {Nombre = "ClubCol", Nombre1 = "Poker"}; //Creacion o construccion de las bebidas
/*         |                                                          |
           |                                                          |
           |                                                          |
           --------.                                         _________|
                   |                                        |
                   |                                        |
                   |  */  //                                |
Bebida Cerveza1 = Cerveza; //Creacion de variable "Cerveza" | a nombre de la variable "Cerveza"
//     |                                                    |
Cerveza1.Nombre1 = "Poker"; //Nuevo nombre para una Cerveza,| a partir de la nueva variable unida a un objeto en el constructor
//               |                                          |
//               |__________________________________________|

//CON "Cerveza1.Nombre1 = "Poker; " SE LE PUEDE MODIFICAR EL NOMBRE POR DEFECTO EN EL CONSTRUCTOR, EN ESTE CASO LA MARCA Ejemplo: "Cerveza1.Nombre1 = "PokerPoker Mod";

//Bebida Cerveza2 = Cerveza;
                         


Console.WriteLine(Cerveza.Nombre +" y "+ Cerveza.Nombre1);



/*Solo sale La ultima cerveza ingresada en el mismo espacio de memoria.Nombre,

si se desea que salga La bebida o bebidas que uno quiera Se Asigna una nueva 

Variable de memoria el la clase Bebida {get; set;}. Ejemplo: Nombre y Nombre1

Para dos clases diferentes de cerveza. Recuerda que si no se hace esto Siempre 

saldra la ultima ingresada en el mismo espacio de memoria {get; set;}*/
 
        

//*CONCATENACION DE CADENAS:

//Normalmente se hacen de la siguiente forma:
Console.WriteLine("");
Console.WriteLine("3* Concatenaciones: ");


string result = "";    //Forma abreviada de un ciclo orientado a una operacion numerica

for (int i = 0; i <= 10; i++)
result += i + ",";
//---------------------------
Console.WriteLine(result);
Console.WriteLine("");       
/* Pero Microsoft Saco una nueva posibilidad de Concatenar en .NET
con el elemento "StringBuilder":



*Ejem:

Primero Se Add Arriba:  using System.Text;

Luego Las lineas de codigo:
*/

StringBuilder sb = new StringBuilder(""); //StringBuilder

for (int i = 0; i <= 10; i++)

sb.Append($"{i},");
Console.WriteLine(sb);


/*NOTA: La concatenacion sirve para ahorrar ingreso de lineas de codigo, "StringBuilder" 
        Es la mejor opcion para Trabajar con muchos datos por que fuera de que ahorra leneas de codigo
        tambien hace la App mas rapida en funcionamiento
 */   


// *DIFERENCIA ENTRE "Constantes y ReadOnly"
/* 

La diferencia entre estas dos variables es que la una se puede modificar y

la otra no.

Ejemplo:


* Vamos primero a la clase Anidada e instanciamos la base de memoria: 

- Con la Constante hay que asignar una afirmacion o valor, osea; 
____________________________________________________________________
public const bool Tiene_Alcohol = true;
--------------------------------------------------------------------

- Con ReadOnly no hay necesidad de asignarlo, osea
________________________________
public readonly string Tiene_Alcohol; //(El valor se pone en el constructor)
--------------------------------

public Bebida(){

    Brand = Modelo;

Si Creamos un Constructor Quitamos el "(string brand)" de la clase y hacemos 

lo siguiente:

var CervezaLight = new Cerveza() {Nombre = "Cerveza Light"};

Ya cuando esta hecho no se puede modificar el valor...




}

*/

Console.WriteLine("");
Console.WriteLine("4* Cambio de asignacion --Brand-- :");
Console.WriteLine(CervezaA.Brand);  //  Consola Readonly


//* DIFERENCIA ENTRE "List" e IEnumerable 

/*
Las difernecias normalmente radican en  que una es una interfaz y otra es una clase, la una 

permite readonly y la otra no pero crea metodos a partir de nuevos objetos.

EJemplo:

Despues del Main...

IEnumerable<int> numeros = new List<int>()
{
1,2,3,4

};

List<int> numeros2 = new List<int>()

{

1,2,3,4
}

A //*"IEnumerable" 

no le puedo agregar nuevos elementos directamente con la 

interface, igualmente si se puede modificar pero de otra forma. Ahora //*"List"

se le puede agregar una gama de muchos metodos Asi:

numeros2.Add(2);
numeros2.Add(5);

Volviendo a el IEnumerable podemos obtener una modificacion de consulta:


var numerosSortDescending = from d in numeros //*"SortDescending" es orden descendente
                            orderby d descending
                            select d;

Y luego imprimimos con el metodo foreach: 

foreach (var n in numerosSortDescending)
Console.WriteLine(n);

E imprime de forma descendente: Asi se puede modificar el IEnumerable

Si Colocamos la variable "numeros2"(que pertenece a "List") en el foreach queda asi

foreach (var n in numeros2)
Console.WriteLine(n);

Y se edita como mutable y se imprime en orden normal.

Recuerda que hay que agregar... arriba el  "using System.Globalization;" para evitar errores

Vamos a Hacerlo real:
  */      
  
IEnumerable<int> numeros = new List<int>()
{
1,2,3,4

};

List<int> numeros2 = new List<int>()

{

1,2,3,4

};

numeros2.Add(2);  //Modificador de objetos "List"
numeros2.Add(5);  

var numerosSortDescending = from n in numeros //*"SortDescending" es orden descendente
                            orderby n descending
                            select n;



Console.WriteLine(" ");

Console.WriteLine("IEnumerable: "); //Titulo en la consola
//--------------------------------------
//foreach para imprimir...(IEnumerable)
foreach (var n in numerosSortDescending)
Console.WriteLine(n);
//--------------------------------------

Console.WriteLine("");

Console.WriteLine("List");

//---------------------------------
//foreach para imprimir...(List)
foreach (var n in numeros2)
Console.WriteLine(n);
//---------------------------------

Console.WriteLine("");
Console.WriteLine("Los ultimos 2 numeros (2 y 5)Son el resultado de  (numeros2.Add(); ) ");
Console.WriteLine("");


/*

Ahora vamos a hacer un ejemplo de un Horario para cualquier zona, esto con el 

fin de no caer en un error con el codigo cuando el Framework o el SO tengan

diferentes idiomas o zonas horarias, para que no haya dificultades en este tipo 

de asignacion se haria de la siguiente forma para que quede en el orden que se

quiera evadiendo el orden de las otras sonaz horarias o idiomas:

Despues del Main....:

var date = DateTime.ParseExact("01-12-2021", "dd-MM-yyyy", CultureInfo.InvariantCulture);
var date2 = DateTime.ParseExact("01-12-2021", "dd-MM-yyyy", CultureInfo.InvariantCulture);

Console.WriteLine($"{date.Day}-{date.Month}-{date.Year}");
Console.WriteLine($"{date2.Day}-{date2.Month}-{date2.Year}");

Ahora vamos a hacerlo real...
*/
Console.WriteLine("Fechas: ");

var date = DateTime.ParseExact("01-12-2021", "dd-MM-yyyy", CultureInfo.InvariantCulture);
var date2 = DateTime.ParseExact("2021-12-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);

Console.WriteLine($"{date.Day}-{date.Month}-{date.Year}");
Console.WriteLine($"{date2.Day}-{date2.Month}-{date2.Year}");


Console.WriteLine("");
  

//*LISTA DE OBJETOS (Cuantos Hay en la Bd?)

/*

Ahora utilizando la misma clase "Bebidas" vamos a utilizar todo lo explicado 
arriba para editar una lista de contadores. Como se hace de modo clasico
y modo abreviado(Que oviamente es Mejor)

//*Ejemplo 1  (El Tradiciona):

var NuevasCervezas = new List<Bebida>(){

 new Bebida(){Nombre = "Aguila"},
 new Bebida(){Nombre = "Heinicken"},
 new Bebida(){Nombre = "Costeña"},
 new Bebida(){Nombre = "Corona"},

};
int coronaBebidas = 0;
foreach(var b in NuevasCervezas)

if(b.Nombre.Equals("Corona"))   //FORMA TRADICIONAL Y MAS ENGORROSA POR QUE HAY ESCRIBIR MUCHAS LINEAS DE CODIGO
        coronaBebidas++;

        Console.WriteLine(coronaBebidas);

        //--------------------------------

//*Ejemplo 2  (El Mas Comodo):

HaY UNA FORMA DECLARATIVA DE HACERLO CON METODOS ENCADENADOS
Y ES DE LA SIGUIENTE FORMA (PARA AHORRAR LINEAS DE CODIGO AL 
TRATAR DE HACER LA MISMA CONSULTA...):

En otras palabras Cadena de Metodos, Abstraccion o programacion declarativa...Similar a como trabaja nuestro pensamiento

 int coronaBebidas2 = NuevasCervezas.Where(d =>d.Nombre.Equals("Corona")).Count(); 
}

//*Sirve Mucho en Consultas SQL con cualquiera de los dos ejemplos, pero es mas comodo con el segundo(Metodos Encadenados)


//*Si en La lista Hay dos marcas u definiciones iguales, por ejemplo, Aguila en 2 veces el resultado sera

2, si hay 1000 repetidas pues saldra mil... y asi sucesivamente asi que para hacer la diferencia y que sea

mas entendible vamos a colocar el ejemplo tradicional 2 "Coronas", y 3 Heinickens

en el ejemplo (Metodos en cadena)...



Vamos a Hacerlo Real...
*/
Console.WriteLine("Lista de Cervezas: ");
Console.WriteLine("");

var NuevasCervezas = new List<Bebida>(){//Para no poner los objetos del constructor en fila se pucieron abajo en columna

 new Bebida(){Nombre = "Aguila"},
 new Bebida(){Nombre = "Heinicken"},
 new Bebida(){Nombre = "Heinicken"},
 new Bebida(){Nombre = "Heinicken"},
 new Bebida(){Nombre = "Costeña"},
 new Bebida(){Nombre = "Corona"},
 new Bebida(){Nombre = "Corona"},

};
int coronaBebidas = 0;
foreach(var b in NuevasCervezas)

if(b.Nombre.Equals("Corona"))            //Forma tradicional o con condicionales
        coronaBebidas++;


Console.WriteLine("Ejemplo 1.. Cuantas Coronas Hay?: ");
Console.Write("R:// : ");

        Console.WriteLine(coronaBebidas); //Respuesta 1

        //--------------------------------

        int HeinickenBebidas = NuevasCervezas.Where(d =>d.Nombre.Equals("Heinicken")).Count(); //Cadena de Metodos Abstraccion o programacion declarativa
Console.WriteLine("");
Console.WriteLine("Ejemplo 2.. Heinickens Hay?: ");

Console.Write("R:// : ");
        Console.WriteLine(HeinickenBebidas); //Respuesta 2

/*METODO MARA MODIFICAR VALORES ALFABETICOS EN UN DOCUMENTO O APP:

Para esto vamos a utilizar la ayuda de .Net con //*"Replace" y "ToUpper"



{
        SI copiamos el siguiente codigo no se genera el cambio (A Mayuscula) por que 
        hay una declaracion de variable tipo string:

        string name = "Zantiagoth";
        

         //*Pero si se escribe lo siguiente...

        name.Replace("c", "k");
        name.ToUpper();
        Console.WriteLine(name);

        //* Si da resultado y el dato ingresado pasa a ser en Mayuscula

}
*/
Console.Write("");
Console.WriteLine("De minusculas a Mayusculas: ");
Console.Write("");


      string name = "Zantiagoth";
        
        name.Replace("c", "k");
        name.ToUpper();
        Console.WriteLine(name);

  name = name.Replace("c", "k");
  name = name.ToUpper();
  Console.WriteLine(name);



Console.WriteLine("");
Console.WriteLine("");
Console.WriteLine("");
Console.WriteLine("FIN");


    }




//CLASE "Bebida" ANIDADA 
public class Bebida


{  //ESPACIOS DE MEMORIA "Nombre"
      public string Nombre {get; set;}
      public string Nombre1 {get; set;}

      public string Nombre2 {get; set;} //* Memoria para const o readonly

      public const bool Tiene_Alcohol = true; // *variable const 
      public readonly string Brand;

      
      //Objeto Clase Bebida
      public Bebida(){ //------.    
                       //      |
      Brand = "Cola_y_Pola"; /*Con Brand Se puede modificar el valor de 
     
      Nombre2,

      sin necesidad de regresar al constructor a modificarlo cuando sea

      necesario...Si en Memoria Nombre2 era Cerveza Ligth y creo el Brand

      en la misma clase Bebida Le puedo cambiar el valor a cualquier otro

      en este caso se paso de Cerveza Ligth A Cola_y_Pola

      //* NOTA: El Brand Hace efecto en un espacio de memoria aleatorio dentro de un constructor,
                que contiene varios espacios de memoria en su interior..
                Si se quiere generar cambio de uno especifico toca hacer un constructor aparte para ese
                espacio de memoria que se desee modificar con el brand

      */

      }
}

    }}
        


